import logo from './logo.svg';
import './App.css';
import React from 'react';
import Tooltip, { TooltipProps, tooltipClasses } from '@mui/material/Tooltip';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import Backdrop from '@mui/material/Backdrop';
import Divider from '@mui/material/Divider';
import LinearProgress, { linearProgressClasses } from '@mui/material/LinearProgress';
import CircularProgress, {
  CircularProgressProps,
} from '@mui/material/CircularProgress';

let refreshTimer = null;

function App() {
  const [isLoadingIndicatorOpen, setLoadingIndicatorOpen] = React.useState(false);
  const [serverURL, setServerURL] = React.useState("http://localhost:5001/");

  const [allStudents, setAllStudents] = React.useState([
    // { "studentID": "810196487", "name": "Ali Mahdavifar" },
    // { "studentID": "810196488", "name": "Ali Mahdavifarr" }
  ]);

  const [allAttempts, setAllAttempts] = React.useState([
    // { "studentID": "810196487", "date": "2023-04-29 13:39:44.582498", "status": "failed", "method": "RFID" }
  ]);

  const [studentIDsWithoutExits, setStudentIDsWithoutExits] = React.useState([]);

  const [hasLoaded, setHasLoaded] = React.useState(false);

  const getNameFromStudentIDWithTwoDashes = (id) => {
    const resultArray = allStudents.filter((student) => {
      return student.studentID == id;
    });
    if (resultArray.length == 0) return "ID ";
    return resultArray[0].name + " -- ";
  }

  const findStudentIDsWithoutExits = (attempts) => {
    let studentIDsWithoutExits = [];
    const uniqueStudentIDs = [...new Set(attempts.map((attempt) => {
      return attempt.studentID;
    }))];
    for (let studentID of uniqueStudentIDs) {
      if (studentID == undefined) continue;
      let count = 0;
      let latestDate = Date.parse("2001-04-25 13:39:44.582498");
      for (let attempt of attempts) {
        if (attempt.studentID == studentID && attempt.status == "succeeded") {
          count += 1;
          if (Date.parse(attempt.date) > latestDate) {
            latestDate = Date.parse(attempt.date);
          }
        }
      }
      console.log("id", studentID, count, Date.now() - latestDate);
      if (count % 2 == 1 && Date.now() - latestDate > 8 * 60 * 60 * 1000) {
        studentIDsWithoutExits.push(studentID);
      }
    }
    return studentIDsWithoutExits;
  }

  const parseAllLogs = (rawData) => {
    let attempts = [];
    for (let data of rawData["success"]) {
      attempts.push({ "studentID": data["std_id"], "date": data["date"], "status": "succeeded", "method": data["Method"] });
    }
    for (let data of rawData["failures"]) {
      attempts.push({ "image_path": data["image_path"], "date": data["date"], "status": "failed", "method": data["Method"] });
    }
    // sort attempts by date
    attempts.sort((a, b) => {
      return new Date(b.date) - new Date(a.date);
    });
    setAllAttempts(attempts);
    setTimeout(() => {
      setStudentIDsWithoutExits(findStudentIDsWithoutExits(attempts));
    }, 100);
  }

  const parseAllStudents = (rawData) => {
    let students = [];
    for (const [key, value] of Object.entries(rawData)) {
      students.push({ "studentID": key, "name": value["Name"] + " " + value["Last_Name"] });
    }
    setAllStudents(students);
  }

  const getAllLogs = () => {
    fetch(serverURL + "getAllLogs", {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      body: JSON.stringify({})
    })
      .then(response => response.json())
      .then(data => {
        if (data["success"] == true) {
          parseAllLogs(data["result"]);
        } else {
          alert("An error occured. Please try again later.");
        }
      })
      .catch(error => {
        console.log(error);
        alert("An error occured. Please try again.");
      });
  }

  const getAllStudents = () => {
    setLoadingIndicatorOpen(true);
    fetch(serverURL + "getAllStudents", {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      body: JSON.stringify({})
    })
      .then(response => response.json())
      .then(data => {
        setLoadingIndicatorOpen(false);
        if (data["success"] == true) {
          parseAllStudents(data["result"]);
        } else {
          alert("An error occured, please try again later.");
        }
      })
      .catch(error => {
        setLoadingIndicatorOpen(false);
        console.log(error);
        alert("An error occured, please try again.");
      });
  }

  const removeStudent = (studentID) => {
    setLoadingIndicatorOpen(true);
    fetch(serverURL + "removeStudent", {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      body: JSON.stringify({ "id": studentID })
    })
    .then(response => response.json())
    .then(data => {
      setLoadingIndicatorOpen(false);
      if (data["success"] == true) {
        getAllStudents();
      } else {
        alert("An error occured; please try again later.");
      }
    })
    .catch(error => {
      setLoadingIndicatorOpen(false);
      console.log(error);
      alert("An error occured; please try again.");
    });
  }

  const addStudent = (studentID, studentName) => {
    setLoadingIndicatorOpen(true);
    fetch(serverURL + "addStudent", {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      body: JSON.stringify({ "id": studentID, "name": studentName })
    })
    .then(response => response.json())
    .then(data => {
      setLoadingIndicatorOpen(false);
      if (data["success"] == true) {
        getAllStudents();
      } else {
        alert("An error occured; Please try again later.");
      }
    })
    .catch(error => {
      setLoadingIndicatorOpen(false);
      console.log(error);
      alert("An error occured; Please try again.");
    });
  }

  return (
    <>
      <div className='main-container'>
        <h1 class="system-title">✨ Welcome to the student identification system!</h1>
        <br /> <br />
        <input type="text" style={{backgroundColor: 'transparent', width: 500, padding: 10, textAlign: 'center', borderRadius: 10, fontSize: '140%', fontFamily: 'monospace'}} value={serverURL} onChange={(event) => {setServerURL(event.target.value)}} onKeyUp={(e) => {
          if (e.keyCode == 13) {
            setTimeout(() => {
              getAllStudents();
              getAllLogs();
              setTimeout(() => {
                setHasLoaded(true);
              }, 100);
              if (refreshTimer != null) clearInterval(refreshTimer);
              refreshTimer = setInterval(() => {
                getAllLogs();
              }, 1000);
            }, 100);
          }
        }} />
        <br /> <br /> <br />
        {hasLoaded &&
          <Grid container spacing={10}>
            <Grid item xs={6}>
              <div className='each-column'>
                <h2 class="system-subtitle">Registered Students</h2>
                <br />
                <div class="add-student-container">
                  <h3 class="system-subsubtitle" style={{ marginLeft: 10 }}>Add Student</h3>
                  <div class="add-student-text-box-container">
                    <input class="add-student-text-box" type="text" placeholder="Student ID" id="student-id-textbox" />
                    <input class="add-student-text-box" type="text" placeholder="Student Name" id="student-name-textbox" />
                  </div>
                  <div class="add-student-button-container">
                    <button class="add-student-button" style={{ marginLeft: 10 }} onClick={() => {
                      const studentID = document.getElementById("student-id-textbox").value;
                      const studentName = document.getElementById("student-name-textbox").value;
                      if (studentID == "" || studentName == "") {
                        alert("Please enter the student ID and the name correctly.");
                        return;
                      }
                      addStudent(studentID, studentName);
                      document.getElementById("student-id-textbox").value = "";
                      document.getElementById("student-name-textbox").value = "";
                    }}>Add Student</button>
                  </div>
                  <br />
                </div>
                <br />
                <table class="students-table">
                  <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Delete</th>
                  </tr>
                  {allStudents.map((student) => {
                    return (<tr>
                      <td>{student.studentID}</td>
                      <td>{student.name}</td>
                      <td>
                        <button class="delete-student-button" onClick={() => {
                          removeStudent(student.studentID);
                        }}>🗑️</button>
                      </td>
                    </tr>)
                  })}
                </table>
                <br />
              </div>
            </Grid>
            <Grid item xs={6}>
              <div className='each-column'>
                <h2 class="system-subtitle">Recent Login Attempts</h2>
                <br />
                <div class="recent-attempts-container">
                  {allAttempts.map((attempt) => {
                    return (<div><div class="recent-attempt">
                      <div class="recent-attempt-icon-container">
                        {attempt.status == "failed" ? "❌" : "✅"}
                      </div>
                      <div class="recent-attempt-text-container">
                        <strong style={{ fontSize: '130%' }}>{attempt.status == "failed" ? "Failed" : "Successful"} Attempt</strong>
                        <br /> <br />
                        {attempt.status == "succeeded" && <>
                          <span style={{ fontSize: '120%' }}>{getNameFromStudentIDWithTwoDashes(attempt.studentID)}{attempt.studentID}{studentIDsWithoutExits.includes(attempt.studentID) ? " (NO EXIT for > 8 hrs)" : ""}</span>
                          <br /> <br />
                        </>}
                        <span style={{ fontSize: '120%' }}>Attempted to login using {attempt.method == "rfid" ? "RFID" : attempt.method}</span>
                        <br /> <br />
                        <span style={{ fontSize: '120%' }}>Date and time: {new Date(attempt.date).toLocaleString()}</span>
                        
                      </div>
                      {attempt.status == "failed" && attempt.image_path != undefined && attempt.image_path != null && attempt.image_path != "" && <div class="recent-attempt-image-container">
                        <img width="200" height="125" src={serverURL + "/getImage?filename=\"" + attempt.image_path + "\""}/>
                      </div>}
                    </div>
                    <Divider className="divider-list" /> </div>)
                  })}

                </div>
              </div>
            </Grid>
          </Grid>
        }
        <br /> <br />
        <strong>Made by Seyed Parsa Neshaei, Iman Alipour, and Ali Mahdavifar, for the Embedded Systems course project</strong>
      </div>
      <Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={isLoadingIndicatorOpen} >
        <CircularProgress color="inherit" />
      </Backdrop>
    </>
  );
}

export default App;
